package com.example.threescreens

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val strips = mutableListOf<View>()
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (strips.isNotEmpty()) {
            // Повторное нажатие на иконку закрывает эффект раньше
            stopSelf()
            return START_NOT_STICKY
        }
        show()
        handler.postDelayed({ stopSelf() }, DURATION_MS)
        return START_NOT_STICKY
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val third = resources.displayMetrics.widthPixels / 3

        for (side in listOf(Gravity.START, Gravity.END)) {
            val strip = View(this).apply { setBackgroundColor(BLUE) }
            val params = WindowManager.LayoutParams(
                third,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or // касания проходят сквозь
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = side or Gravity.TOP }
            wm.addView(strip, params)
            strips.add(strip)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) strips.forEach { runCatching { wm.removeView(it) } }
        strips.clear()
        super.onDestroy()
    }

    companion object {
        private const val DURATION_MS = 5000L
        private const val BLUE = 0x302F6BFF // слегка синий, ~19% непрозрачности
    }
}
